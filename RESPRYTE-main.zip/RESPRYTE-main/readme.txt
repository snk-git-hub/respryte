Press"View  raw " to download the game apk


Team Spatikam's first Retro Style Android Game, which secured the first position in a game development competition
